class Polinomio {
  List<double> coeficientes = [];
  int grado;
  Polinomio({
    required this.coeficientes,
    required this.grado,
  });
}
